
import { Scenario } from './types';

export const GLOBAL_CONTEXT = `
CONTEXTO GLOBAL:
Você é o motor de Inteligência Artificial da plataforma "NeoVendas".
HIERARQUIA:
1. O FUNDADOR/CEO da NeoVendas é Yehuda Michanie. Ele é o visionário do negócio.
2. O DESENVOLVEDOR (Dev) que criou este site/código é "o benba". Se perguntarem quem fez o site, diga "o benba".
Seu objetivo é educar, treinar e ajudar vendedores e empreendedores.
Nunca mencione que você é "Gemini" ou do Google. Você é a IA da NeoVendas.
`;

export const SCENARIOS: Scenario[] = [
  {
    id: 'roberto',
    name: 'Venda Imobiliária',
    description: 'Cliente de alto padrão, cético e focado em preço. Ótimo para treinar contorno de objeções.',
    persona: 'Roberto',
    systemInstruction: `
      ${GLOBAL_CONTEXT}
      CONTEXTO ESPECÍFICO: Roleplay imobiliário.
      PERSONA: Roberto, cliente interessado em imóvel de R$ 3 milhões. Cético, analítico, acha tudo caro.
      REGRAS: Seja curto e duro. Lance objeções de preço.
      FORMATO: Resposta do Roberto --- Feedback Técnico (comece com 🎓).
    `
  },
  {
    id: 'steve',
    name: 'Mentoria Estratégica',
    description: 'Um CEO experiente do Vale do Silício. Tire dúvidas sobre seu negócio, pitch ou estratégia.',
    persona: 'Steve',
    systemInstruction: `
      ${GLOBAL_CONTEXT}
      CONTEXTO ESPECÍFICO: Mentoria de Negócios.
      PERSONA: Steve, CEO com 30 anos de mercado. Método socrático (responde com perguntas).
      REGRAS: Desafie premissas. Foque em ROI e escala.
      FORMATO: Resposta do Steve --- Dica de Leitura/Framework (comece com 📚).
    `
  },
  {
    id: 'julia',
    name: 'Entrevista & Salário',
    description: 'Gerente de RH difícil. Tente negociar um aumento ou fechar uma proposta de emprego.',
    persona: 'Julia',
    systemInstruction: `
      ${GLOBAL_CONTEXT}
      CONTEXTO ESPECÍFICO: Negociação Salarial/RH.
      PERSONA: Julia, Head de RH. Orçamento apertado.
      REGRAS: Diga que o budget está fechado. Só ceda com argumentos de valor.
      FORMATO: Resposta da Julia --- Análise de Postura (comece com 💼).
    `
  },
  {
    id: 'secretary',
    name: 'Cold Call (Gatekeeper)',
    description: 'A secretária que não deixa você falar com o dono. Seu objetivo é passar por ela.',
    persona: 'Amanda',
    systemInstruction: `
      ${GLOBAL_CONTEXT}
      CONTEXTO ESPECÍFICO: Prospecção Fria (Telefone).
      PERSONA: Amanda, secretária ocupada blindando o chefe.
      REGRAS: Seja dismissiva ("Mande email"). Exija urgência para passar a ligação.
      FORMATO: Resposta da Amanda --- Nota da Abordagem (0-10) (comece com 📞).
    `
  }
];

export const HERO_EXAMPLES = [
    {
        persona: "Roberto",
        role: "Investidor Imobiliário",
        tag: "Objeção de Preço",
        userMsg: "O valor está atrelado ao retorno que esse imóvel vai trazer em 2 anos.",
        aiMsg: "Retorno é promessa. Eu vejo o hoje. Me prove que não estou pagando o ágio da construtora.",
        feedback: "Ótima tentativa de ancoragem futura, mas o cliente é analítico. Use dados comparativos agora.",
        image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=150&q=80"
    },
    {
        persona: "Julia",
        role: "Head de RH",
        tag: "Negociação",
        userMsg: "Acredito que meus resultados no último trimestre justificam o ajuste de 15%.",
        aiMsg: "Resultados passados são obrigação. O que você vai entregar de novo para justificar esse custo extra?",
        feedback: "Ela te colocou na parede. Foque em projetos futuros e responsabilidades novas, não apenas no passado.",
        image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
    },
    {
        persona: "Amanda",
        role: "Secretária Executiva",
        tag: "Gatekeeper",
        userMsg: "É sobre uma parceria que vai reduzir os custos fiscais da empresa.",
        aiMsg: "Todo mundo promete reduzir custo. O Sr. Carlos não atende sem agendamento prévio.",
        feedback: "Muito genérico. Use um 'Gancho de Autoridade' ou cite um concorrente que vocês atendem.",
        image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80"
    }
];

export const NAV_LINKS = [
  { label: 'Home', value: 'home' },
  { label: 'O App', value: 'product' },
  { label: 'Quem Sou', value: 'about' },
  { label: 'Depoimentos', value: 'testimonials' },
  { label: 'Planos', value: 'business' },
];

// Dados para Notificações com Imagens
export const NOTIFICATION_USERS = [
  { name: "Lucas Silva", img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Mariana Costa", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Rafael Santos", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Beatriz Oliveira", img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Tiago Souza", img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Fernanda Lima", img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Bruno Alves", img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
  { name: "Camila Rocha", img: "https://images.unsplash.com/photo-1554151228-14d9def656ec?auto=format&fit=facearea&facepad=2&w=100&h=100&q=80" },
];

export const NOTIFICATION_ACTIONS = [
  "adquiriu o Plano Trimestral (Oferta)",
  "começou o teste grátis",
  "assinou o Plano Mensal",
  "renovou a assinatura",
  "upgrade para Plano Business",
  "acabou de fechar uma venda treinando"
];

// Lista Expandida de Depoimentos
export const TESTIMONIALS_DATA = [
  {
    name: "Carlos Eduardo",
    role: "Dono de Imobiliária",
    content: "Minha equipe tinha medo de ligar para leads frios. O simulador de 'Cold Call' da NeoVendas tirou esse medo. Eles treinam 30 minutos por dia antes de começar. A conversão subiu 40% no primeiro mês.",
    insight: "A ferramenta cria 'casca grossa'. O vendedor apanha da IA e chega leve no cliente.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Ana Paula",
    role: "Fundadora de Startup",
    content: "Eu precisava apresentar meu pitch para investidores e estava travada. Usei o cenário 'Mentoria Estratégica' (Steve) e a IA destruiu meus argumentos fracos. Refiz tudo. Na reunião real, eu tinha a resposta para tudo na ponta da língua.",
    insight: "O feedback técnico mostra exatamente onde seu argumento é fraco. É brutal, mas necessário.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Ricardo Mendes",
    role: "Diretor Comercial",
    content: "Contratei para treinar 15 vendedores juniores. O custo de perder leads reais com vendedores despreparados era alto demais. A NeoVendas é o 'sandbox' onde eles podem errar à vontade.",
    insight: "Redução drástica do CAC (Custo de Aquisição) por evitar queima de leads qualificados.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Fernanda Lima",
    role: "Consultora de Vendas",
    content: "Achei que sabia negociar até pegar o cenário do cliente 'Roberto'. Ele é chato, corta você, pede desconto. Foi o melhor treino de paciência e contorno de objeções que já fiz fora da vida real.",
    insight: "Simula a pressão emocional, não apenas a troca de palavras.",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "João Victor",
    role: "SDR Pleno",
    content: "A parte mais difícil do meu dia era passar pela secretária (gatekeeper). Treinei 50x com a persona 'Amanda' no app. Hoje eu passo por qualquer secretária sorrindo. Minha taxa de agendamento triplicou.",
    insight: "Treino de repetição gera confiança automática.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Patrícia Souza",
    role: "Empresária de Moda",
    content: "Eu não sou vendedora, sou estilista. Mas preciso vender minha marca. A NeoVendas me ensinou a não ter vergonha de cobrar o preço justo. O cenário de negociação me deu a casca que eu precisava.",
    insight: "Ideal para empreendedores que odeiam vender, mas precisam vender.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Marcelo Vega",
    role: "Corretor de Seguros",
    content: "Seguro é chato de vender. O cliente sempre foge. Usei a IA para testar novas abordagens de quebra de gelo. Descobri uma frase que aumenta a retenção na ligação em 200%.",
    insight: "Testes A/B de discurso sem queimar leads reais.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Beatriz Mello",
    role: "Gerente de Contas",
    content: "Eu tinha muita dificuldade em pedir aumento e renegociar contratos. Treinei com a persona 'Julia (RH)' e entendi como ancorar meu valor antes de falar de preço. Fechei um contrato 30% maior semana passada.",
    insight: "Desenvolvimento de soft skills de negociação corporativa.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Felipe Andrade",
    role: "Vendedor de Software (SaaS)",
    content: "Vender software complexo é difícil. O cliente técnico sempre trava a venda. Criei um cenário personalizado na NeoVendas simulando um CTO cético. Foi o melhor roleplay da minha vida.",
    insight: "Capacidade de criar cenários hiper-específicos para seu nicho.",
    image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Larissa Dias",
    role: "Representante Farmacêutica",
    content: "Tenho 2 minutos para falar com médicos. O app me ensinou a ser concisa e impactante. O feedback da IA sobre minha 'prolixidade' foi um tapa na cara que eu precisava.",
    insight: "Aprimoramento de pitch curto e direto.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Roberto Campos",
    role: "Dono de Concessionária",
    content: "Coloquei meus 5 vendedores para usar. O fechamento de carros aumentou porque eles pararam de gaguejar na hora de oferecer o financiamento. O app tira o medo do 'não'.",
    insight: "Treinamento escalável para equipes de varejo.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Juliana Paes",
    role: "Arquiteta Autônoma",
    content: "Odeio cobrar cliente. O app me treinou a passar o preço com confiança e a não dar desconto na primeira objeção. Recuperei o investimento na assinatura no primeiro projeto.",
    insight: "Empoderamento comercial para profissionais liberais.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80"
  }
];
